import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { About } from "@/components/about"
import { WhyChooseUs } from "@/components/why-choose-us"
import { Membership } from "@/components/membership"
import { Programs } from "@/components/programs"
import { Trainers } from "@/components/trainers"
import { Gallery } from "@/components/gallery"
import { Testimonials } from "@/components/testimonials"
import { Faq } from "@/components/faq"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"
import { WhatsAppButton } from "@/components/whatsapp-button"

export default function Page() {
  return (
    <main className="overflow-x-hidden">
      <Navbar />
      <Hero />
      <About />
      <WhyChooseUs />
      <Membership />
      <Programs />
      <Trainers />
      <Gallery />
      <Testimonials />
      <Faq />
      <Contact />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
