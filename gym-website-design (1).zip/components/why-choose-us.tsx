import { BadgeCheck, Dumbbell, Maximize, Sparkles, UserCog, Users } from "lucide-react"
import { Reveal } from "@/components/reveal"

const FEATURES = [
  {
    icon: BadgeCheck,
    title: "Certified Trainers",
    desc: "Qualified coaches who tailor every session to your goals and ability.",
  },
  {
    icon: Dumbbell,
    title: "Premium Equipment",
    desc: "Imported strength and cardio machines maintained to the highest standard.",
  },
  {
    icon: Maximize,
    title: "Spacious Workout Area",
    desc: "Train without crowding in our wide, thoughtfully laid-out floor.",
  },
  {
    icon: Sparkles,
    title: "Clean & Hygienic",
    desc: "Sanitised equipment and a fresh environment, every single day.",
  },
  {
    icon: UserCog,
    title: "Personalized Guidance",
    desc: "One-on-one programming and form checks to keep you progressing safely.",
  },
  {
    icon: Users,
    title: "Community Atmosphere",
    desc: "Train alongside a motivated community that pushes each other higher.",
  },
]

export function WhyChooseUs() {
  return (
    <section id="why" className="border-y border-border bg-card/30">
      <div className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-primary">
            Why Choose Us
          </p>
          <h2 className="mt-4 text-balance text-3xl font-extrabold uppercase leading-tight tracking-tight sm:text-4xl">
            Everything You Need to Succeed
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            We obsess over the details so you can focus on the work. Here&apos;s what makes
            this concept stand out.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feature, i) => (
            <Reveal
              key={feature.title}
              delay={i * 80}
              className="group rounded-2xl border border-border bg-card p-7 transition-colors hover:border-primary/50"
            >
              <span className="flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <feature.icon className="size-6" />
              </span>
              <h3 className="mt-5 text-lg font-bold">{feature.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {feature.desc}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
